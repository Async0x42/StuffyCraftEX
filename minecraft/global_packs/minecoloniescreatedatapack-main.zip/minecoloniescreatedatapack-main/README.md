# minecoloniescreatedatapack
Datapack from Shadizar to enable better integration between core Create mod and Minecolonies.


Deliberately excludes items made with mechanical crafting, manual items like andesite casing, and non crafting table recipes for simplicity; does not do stonecutter-requiring items yet. This is tested on create-1.19.2-0.5.1.b and later; datapack is untested on prior versions of Create.

I also rearranged some of the colonists (sometimes the auto detection for which colonist would make which recipe were logically a bit off).

This is about as complete as I intend to do on this effort, barring any significant motivation that might come up to polish it a bit more later (mostly stonecutter style stuff is what's missing, in my opinion, for a few items).
